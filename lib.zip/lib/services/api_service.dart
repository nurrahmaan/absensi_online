import 'dart:io';
import 'package:absensi_online/models/approval.dart';
import 'package:dio/dio.dart';
import '../config/api_config.dart';

class ApiService {
  final Dio _dio = Dio(BaseOptions(
    baseUrl: ApiConfig.baseUrl,
    connectTimeout: ApiConfig.connectTimeout,
    receiveTimeout: ApiConfig.receiveTimeout,
  ));

  // ===== Cek Koneksi Internet =====
  Future<bool> hasInternetConnection() async {
    try {
      final result = await InternetAddress.lookup('google.com');
      return result.isNotEmpty && result[0].rawAddress.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  // ===== Cek Koneksi ke Server =====
  Future<bool> hasServerConnection() async {
    try {
      final response = await _dio.get('/ping');
      // print("Ping response: ${response.data}"); // <-- cek isi response
      return response.statusCode == 200 && response.data['status'] == 'success';
    } catch (e) {
      print("Ping error: $e"); // <-- cek error kalau gagal
      return false;
    }
  }

  // ===== Login =====
  Future<Map<String, dynamic>> login(String username, String password) async {
    try {
      Response response = await _dio.post('/auth/login', data: {
        'username': username,
        'password': password,
      });
      return response.data;
    } on DioException catch (e) {
      if (e.response != null) {
        return e.response?.data ??
            {
              'success': false,
              'message': 'Login gagal, periksa username/password.'
            };
      } else {
        return {'success': false, 'message': 'Tidak bisa terhubung ke server.'};
      }
    }
  }

  // ===== Jadwal & Absensi Hari Ini =====
  Future<Map<String, dynamic>> getJadwalToday(String token) async {
    try {
      final response = await _dio.get(
        "/absensi/jadwalToday",
        options: Options(headers: {"Authorization": "Bearer $token"}),
      );
      if (response.statusCode == 200 && response.data['success'] == true) {
        final data = response.data['data'];
        if (data is List && data.isNotEmpty) return data[0];
      }
      return {};
    } on DioException catch (e) {
      print("Error getJadwalToday: ${e.message}");
      return {};
    }
  }

  // ===== Ringkasan Bulanan pada dashboard=====
  Future<Map<String, dynamic>> getMonthlySummary(String token) async {
    try {
      final response = await _dio.get(
        "/absensi/monthlySummary",
        options: Options(headers: {"Authorization": "Bearer $token"}),
      );
      if (response.statusCode == 200 && response.data['success'] == true) {
        return response.data['data'] ?? {};
      }
      return {};
    } on DioException catch (e) {
      print("Error getMonthlySummary: ${e.message}");
      return {};
    }
  }

  // ===== History Bulanan=====
  Future<Map<String, dynamic>> getHistory(String token,
      {int? month, int? year}) async {
    try {
      final response = await _dio.get(
        "/absensi/history",
        queryParameters: {
          if (month != null) "month": month.toString(),
          if (year != null) "year": year.toString(),
        },
        options: Options(headers: {"Authorization": "Bearer $token"}),
      );
      // print("GET /absensi/history with params: month=$month, year=$year");

      if (response.statusCode == 200 && response.data['history'] != null) {
        return response.data;
      }
      return {};
    } on DioException catch (e) {
      print("Error getHistory: ${e.response?.data ?? e.message}");
      return {};
    }
  }

  // ===== 5 Hari Terakhir =====
  Future<List<Map<String, dynamic>>> getLastFiveDays(String token) async {
    try {
      final response = await _dio.get(
        "/absensi/lastfiveDays",
        options: Options(headers: {"Authorization": "Bearer $token"}),
      );
      if (response.statusCode == 200 && response.data['success'] == true) {
        final data = response.data['data'];
        if (data is List) return List<Map<String, dynamic>>.from(data);
      }
      return [];
    } on DioException catch (e) {
      print("Error getLastFiveDays: ${e.message}");
      return [];
    }
  }

  // ===== User Profile =====
  Future<Map<String, dynamic>> getUserProfile(String token) async {
    try {
      final response = await _dio.get(
        '/user/profile',
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );

      if (response.statusCode == 200 &&
          response.data['data'] != null &&
          response.data['data'].isNotEmpty) {
        return response.data['data'][0]; // ambil user pertama
      }
      return {};
    } catch (e) {
      print('getUserProfile error: $e');
      return {};
    }
  }

  // ===== Quick Absen (lama) =====
  Future<bool> quickAbsen(String token) async {
    try {
      final response = await _dio.post(
        '/quick_absen',
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );
      return response.data['success'] == true;
    } catch (e) {
      print('quickAbsen error: $e');
      return false;
    }
  }

  // ===== Absen In/Out (baru) =====
  Future<Map<String, dynamic>> absen(String token, String type) async {
    try {
      final response = await _dio.post(
        '/absensi/checkin',
        data: {"type": type}, // contoh: { "type": "in" } atau { "type": "out" }
        options: Options(headers: {"Authorization": "Bearer $token"}),
      );
      // print(response);
      return response.data;
    } on DioException catch (e) {
      if (e.response != null) {
        return e.response?.data ?? {'success': false, 'message': 'Gagal absen'};
      } else {
        return {'success': false, 'message': 'Tidak bisa terhubung ke server'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Error: $e'};
    }
  }

  // di ApiService
  Future<List<Map<String, dynamic>>> getLokasiKantor(String token) async {
    try {
      final response = await _dio.get(
        '/absensi/kantor',
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );

      if (response.statusCode == 200 && response.data['kantor'] != null) {
        final List data = response.data['kantor'];
        return data.map<Map<String, dynamic>>((item) {
          // Parsing aman untuk lat/lng/radius
          double? parseDouble(dynamic value) {
            if (value == null) return null;
            return double.tryParse(value.toString());
          }

          return {
            "id": item['id'],
            "name": item['nama_kantor'] ?? "Tidak diketahui",
            "lat": parseDouble(item['latitude_kantor']),
            "lng": parseDouble(item['longitude_kantor']),
            "radius": parseDouble(item['radius']) ?? 30.0,
            "aktif": item['aktif'] ?? "N",
            "alamat": item['alamat_kantor'] ?? "",
          };
        }).toList();
      }

      return [];
    } on DioException catch (e) {
      print("getLokasiKantor error: ${e.message}");
      return [];
    } catch (e) {
      print("getLokasiKantor unknown error: $e");
      return [];
    }
  }

  // ===== Ganti Password =====
  Future<Map<String, dynamic>> changePassword({
    required String token,
    required String oldPassword,
    required String newPassword,
  }) async {
    try {
      final response = await _dio.post(
        '/user/change-password',
        data: {
          'old_password': oldPassword,
          'new_password': newPassword,
        },
        options: Options(headers: {'Authorization': 'Bearer $token'}),
      );

      if (response.statusCode == 200) {
        return response.data; // { success: true, message: "..."}
      } else {
        return {
          'success': false,
          'message': response.data['message'] ?? 'Gagal ganti password'
        };
      }
    } on DioException catch (e) {
      if (e.response != null) {
        return e.response?.data ??
            {'success': false, 'message': 'Gagal ganti password'};
      } else {
        return {'success': false, 'message': 'Tidak bisa terhubung ke server'};
      }
    } catch (e) {
      return {'success': false, 'message': 'Error: $e'};
    }
  }

  /// Fetch daftar approvals (cuti & izin)
  Future<List<Approval>> getApprovals(String token) async {
    try {
      final response = await _dio.get(
        "/absensi/approvals",
        options: Options(
          headers: {
            HttpHeaders.authorizationHeader: "Bearer $token",
          },
        ),
      );

      if (response.statusCode == 200) {
        // Pastikan response.data selalu berupa List
        final data = response.data;
        if (data is List) {
          return data.map((json) => Approval.fromJson(json)).toList();
        } else {
          throw Exception("Format response tidak sesuai (expected List)");
        }
      } else {
        throw Exception("Gagal memuat data approvals: ${response.statusCode}");
      }
    } on DioException catch (e) {
      // Lebih jelas untuk debug error
      final message = e.response?.data ?? e.message;
      throw Exception("Gagal menghubungi server: $message");
    } catch (e) {
      throw Exception("Terjadi kesalahan: $e");
    }
  }
}
