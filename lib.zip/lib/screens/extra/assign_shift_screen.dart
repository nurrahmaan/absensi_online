import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth/user_provider.dart';

class AssignShiftScreen extends StatefulWidget {
  const AssignShiftScreen({super.key});

  @override
  State<AssignShiftScreen> createState() => _AssignShiftScreenState();
}

class _AssignShiftScreenState extends State<AssignShiftScreen> {
  bool _loadingProfile = true;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    await userProvider.loadUserProfile();
    setState(() {
      _loadingProfile = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final userProvider = context.watch<UserProvider>();

    if (_loadingProfile || userProvider.isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    // Ambil jabatan dari userProfile
    final jabatan = userProvider.userProfile['jabatan'] ?? '';

    return Scaffold(
      appBar: AppBar(title: const Text("Assign Shift")),
      body: ListView(
        children: [
          ListTile(
            title: const Text('Daftar Shift'),
            onTap: () {
              // Aksi daftar shift
            },
          ),
          const Divider(),

          // Menu tambahan hanya untuk Koordinator
          if (jabatan == 'Koordinator')
            ListTile(
              title: const Text('Menu Khusus Koordinator'),
              subtitle: const Text('Hanya muncul untuk Koordinator'),
              leading: const Icon(Icons.admin_panel_settings),
              onTap: () {
                // Aksi khusus Koordinator
              },
            ),
        ],
      ),
    );
  }
}
