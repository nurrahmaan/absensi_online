import 'package:absensi_online/providers/auth/user_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'shift_management_screen.dart';
import 'e_library_screen.dart';
import 'approval_status_screen.dart';

class MoreScreen extends StatefulWidget {
  const MoreScreen({super.key});

  @override
  State<MoreScreen> createState() => _MoreScreenState();
}

class _MoreScreenState extends State<MoreScreen> {
  bool _loadingProfile = true;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    await userProvider.loadUserProfile();
    setState(() {
      _loadingProfile = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final userProvider = context.watch<UserProvider>();

    if (_loadingProfile || userProvider.isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final jabatan = userProvider.userProfile['jabatan'] ?? '';

    // Daftar menu default
    final List<Map<String, dynamic>> menuItems = [
      {
        'title': 'Status Persetujuan',
        'subtitle': 'Izin, Cuti, dan Dispensasi',
        'icon': Icons.assignment_turned_in,
        'screen': ApprovalStatusScreen(token: ''),
      },
      {
        'title': 'Lembur & Shift Management',
        'subtitle': 'Kelola jadwal shift dan lembur',
        'icon': Icons.access_time,
        'screen': ShiftManagementScreen(token: ''),
      },
      {
        'title': 'E-Library',
        'subtitle': 'Akses dokumen dan referensi',
        'icon': Icons.menu_book,
        'screen': ELibraryScreen(token: ''),
      },
    ];

    // Tambahkan menu khusus Koordinator
    if (jabatan == 'Koordinator') {
      menuItems.add({
        'title': 'Menu Khusus Koordinator',
        'subtitle': 'Hanya muncul untuk Koordinator',
        'icon': Icons.admin_panel_settings,
        'screen': null, // bisa diganti screen khusus
      });
    }

    return Scaffold(
      appBar: AppBar(title: const Text("Menu Lainnya")),
      body: ListView.separated(
        itemCount: menuItems.length,
        separatorBuilder: (_, __) => const Divider(),
        itemBuilder: (context, index) {
          final item = menuItems[index];
          return ListTile(
            leading: Icon(item['icon']),
            title: Text(item['title']),
            subtitle: Text(item['subtitle']),
            onTap: item['screen'] != null
                ? () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => item['screen']),
                    );
                  }
                : null, // jika null, tidak ada aksi
          );
        },
      ),
    );
  }
}
